import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import java.util.InputMismatchException;

import static org.junit.jupiter.api.Assertions.assertThrows;

public class GuessNumberIOTest {
    private final InputStream originalSystemIn = System.in;
    private final PrintStream originalSystemOut = System.out;
    private ByteArrayOutputStream capturedOutput;

    private final String introMessage = "A number is chosen between 1 to 100. Guess the number within 5 trials.\n";
    private final String victoryMessage = "Guess the number: Congratulations! You guessed the number.";
    private final String gameOverMessage = "You have exhausted 5 trials.\n" + "The number was ";
    private final String hintLessThan = "Guess the number: The number is less than ";
    private final String hintGreaterThan = "Guess the number: The number is greater than ";

    @BeforeEach
    public void setUpOutputStream() {
        capturedOutput = new ByteArrayOutputStream();
        System.setOut(new PrintStream(capturedOutput));
    }

    private String getCapturedOutput() {
        return capturedOutput.toString();
    }

    @AfterEach
    public void resetSystemIOStreams() {
        System.setIn(originalSystemIn);
        System.setOut(originalSystemOut);
    }

    private void simulateUserInput(String inputData) {
        ByteArrayInputStream simulatedInput = new ByteArrayInputStream(inputData.getBytes(StandardCharsets.UTF_8));
        System.setIn(simulatedInput);
    }

    private Random mockRandomWithFixedOutput(final int fixedValue) {
        return new Random() {
            @Override
            public int nextInt(int bound) {
                return fixedValue; // Mocking to always return a fixed number
            }
        };
    }

    @Test
    public void testIncorrectGuessesExhaustTrials() {
        Random mockRandom = mockRandomWithFixedOutput(20); // Mocked to always aim for the target number 21
        simulateUserInput("9 25 15 30 5");
        GuessNumber.guessingNumberGame(mockRandom);

        StringBuilder expectedOutput = new StringBuilder(introMessage)
                .append(hintGreaterThan).append("9\n")
                .append(hintLessThan).append("25\n")
                .append(hintGreaterThan).append("15\n")
                .append(hintLessThan).append("30\n")
                .append(hintGreaterThan).append("5\n")
                .append(gameOverMessage).append("21\n");

        Assertions.assertEquals(expectedOutput.toString(), getCapturedOutput());
    }

    @Test
    public void testGuessRightWithinFiveTrials() {
        Random mockRandom = mockRandomWithFixedOutput(20); // Mocked to always aim for the target number 21
        simulateUserInput("10 18 20 22 25");
        GuessNumber.guessingNumberGame(mockRandom);

        StringBuilder expectedOutput = new StringBuilder(introMessage)
                .append(hintGreaterThan).append("10\n")
                .append(hintGreaterThan).append("18\n")
                .append(hintGreaterThan).append("20\n")
                .append(hintLessThan).append("22\n");

        Assertions.assertNotEquals(expectedOutput.toString(), getCapturedOutput());
    }

    @Test
    public void testInvalidInputType() {
        Random mockRandom = mockRandomWithFixedOutput(20); // The number to guess
        simulateUserInput("abc");

        assertThrows(InputMismatchException.class, () -> GuessNumber.guessingNumberGame(mockRandom));
    }

    @Test
    public void testInputBeyondBounds() {
        Random mockRandom = mockRandomWithFixedOutput(20); // The number to guess
        simulateUserInput("105");

        assertThrows(InputMismatchException.class, () -> GuessNumber.guessingNumberGame(mockRandom));
    }

    @Test
    public void testNonIntegerInput() {
        Random mockRandom = mockRandomWithFixedOutput(20); // The number to guess
        simulateUserInput("3 4 5 20.0");

        assertThrows(InputMismatchException.class, () -> GuessNumber.guessingNumberGame(mockRandom));
    }
}
