import org.junit.jupiter.api.Test;
import java.util.HashMap;
import java.util.Random;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class GuessNumberRandomnessTest {
    @Test
    public void testRandomness() {
        HashMap<Integer, Integer> frequencyMap = new HashMap<>();
        Random rnd = new Random(0); // Fixed seed for reproducibility

        // Assuming guessingNumberGame now directly returns a random number for this test context
        for (int i = 0; i < 30000; i++) {
            int result = guessingNumberGame(rnd); // Adjust to fit the actual method signature
            frequencyMap.merge(result, 1, Integer::sum);
        }

        double expectedFrequency = 30000 / 100.0; // Expected frequency for each of the 100 numbers
        frequencyMap.values().forEach(actualFrequency ->
                assertTrue(
                        actualFrequency >= expectedFrequency * 0.5 && actualFrequency <= expectedFrequency * 1.5,
                        "The distribution of generated numbers is not uniformly distributed."
                )
        );
    }

    // Stub for the guessingNumberGame method to illustrate the concept
    // Replace this stub with the actual method from your GuessNumber class
    private int guessingNumberGame(Random rnd) {
        return rnd.nextInt(100) + 1;
    }
}
