import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class JsonplaceholderRestAPITest{

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "https://jsonplaceholder.typicode.com";
    }

    @Test
    public void testAlbumsEndpointForSpecificTitle() {
        RestAssured.given()
                .get("/albums")
                .then()
                .statusCode(200)
                .body("title", hasItem("omnis laborum odio"));
    }

    @Test
    public void testCommentsEndpointForCount() {
        RestAssured.given()
                .get("/comments")
                .then()
                .statusCode(200)
                .body("size()", greaterThanOrEqualTo(200));
    }

    @Test
    public void testUsersEndpointForSpecificUser() {
        RestAssured.given()
                .get("/users")
                .then()
                .statusCode(200)
                .body("find { it.name == 'Ervin Howell' }.username", equalTo("Antonette"))
                .body("find { it.name == 'Ervin Howell' }.address.zipcode", equalTo("90566-7771"));
    }

    @Test
    public void testCommentsEndpointForEmailsEndingInBiz() {
        RestAssured.given()
                .get("/comments")
                .then()
                .statusCode(200)
                .body("email.findAll { it.endsWith('.biz') }.size()", greaterThan(0));
    }

    @Test
    public void createPostAndVerify() {
        RestAssured.given()
                .contentType("application/json")
                .body("{\"userId\": 11, \"id\": 101, \"title\": \"sunt aut facere repellat provident occaecati excepturi optio reprehenderit\", \"body\": \"quia et suscipit\\nsuscipit recusandae consequuntur expedita et cum\\nreprehenderit molestiae ut ut quas totam\\nnostrum rerum est autem sunt rem eveniet architecto\"}")
                .post("/posts")
                .then()
                .statusCode(201)
                .body("userId", equalTo(11))
                .body("id", equalTo(101))
                .body("title", equalTo("sunt aut facere repellat provident occaecati excepturi optio reprehenderit"))
                .body("body", equalTo("quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"));
    }
}
